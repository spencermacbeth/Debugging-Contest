package textProcesser;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class SearchEngine {
	//Dictionary that maps a string key to a linked list containing all the pages a word occurs on
	HashMap<String, LinkedList<Integer>> map = new HashMap<String, LinkedList<Integer>>();
	
	//Trie containing all the words of a text file
	Trie trie = new Trie();
	
	//Current page of text being searched
	int pageCounter = 1;
	
	//Delimiter used to decide when increment the pageCounter
	String pageDelimiter = "!!!";

	//setter method for the page delimiter
	public void setPageDelimiter(String s) {
		pageDelimiter = s;
	}

	
	
	public void processText(String filename) throws FileNotFoundException {
		Scanner in = new Scanner(new File(filename));
		// add all words in text to an array
		String word;
		while (in.hasNext()) {
			word = in.next();

			// page delimeter reached, increment page counter for storing values
			if (word.equals(pageDelimiter)) {
				pageCounter++;
				System.out.println("Page Delimiter Reached, on page" + pageCounter);
				continue;
			} else if (!map.containsKey(word)) {
			//If the 
				trie.addWord(word);
				map.put(word, new LinkedList<Integer>());
				map.get(word).add(pageCounter);
			} else if (map.containsKey(word)) {
				map.get(word).add(pageCounter);
			}
		}

	}

	public LinkedList<LinkedList<Integer>> search(String[] words) {
		LinkedList<LinkedList<Integer>> result = new LinkedList<LinkedList<Integer>>();
		for (String w : words) {
			if (w.hashCode() == trie.search(w))
				result.add(map.get(w));
		}
		
		boolean isEmpty = true;
		for(LinkedList<Integer> l : result) {
			if(l != null) {
				isEmpty = false;
			}
		}
		if(isEmpty == true) {
			result = new LinkedList<LinkedList<Integer>>();
		}
		return result;
	}

	public void displayResult(String[] words) {
		LinkedList<LinkedList<Integer>> result = search(words);
		for (LinkedList l : result) {
			if (l != null) {
				System.out.println(l.toString());
			}
		}
	}
}
