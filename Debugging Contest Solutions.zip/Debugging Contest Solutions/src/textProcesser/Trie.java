package textProcesser;

import java.util.LinkedList;

public class Trie {
	Node root = new Node(this);
	Node pointer;
	LinkedList<Node> nodeSet = new LinkedList<Node>();

	public void addWord(String s) {
		pointer = root;
		char[] arr = s.toCharArray();

		for (char c : arr) {
			pointer.addChild(c);
		}
		Node leaf = new Node(true, s.hashCode());
		pointer.addLeafChild(leaf);
		nodeSet.add(leaf);

	}


	public void display() {
		pointer = root;
		for (Node n : nodeSet) {
			System.out.println();
			System.out.print("Node Value: " + n.c + ", Children: ");
			for (char c : n.childValues()) {
				System.out.print(c + ", ");
			}
			if (n.isLeaf) {
				System.out.print(", isLeaf: " + n.isLeaf + ", hashcode: " + n.leafValue);
			}
		}
	}

	//Called from the SearchEngine.search(String[] s) method
	//Traverses the trie to find the pattern.
	public int search(String pattern) {
		pointer = root;
		int idx = 0;
		while (!pointer.isLeaf) {
			if (pointer.childValues().contains(pattern.charAt(idx))) {
				System.out.println(pointer.childValues().toString());
				for (int i = 0; i < pointer.children.size(); i++) {
					if (pointer.children.get(i).c.contains(pattern.charAt(idx))) {
						pointer = pointer.children.get(i);
						idx++;
					}
				}
			}
		}
		return pointer.leafValue;
	}

	public void hasLeaf() {
		for (Node n : nodeSet) {
			if (n.isLeaf) {
				System.out.println("true");
			}
		}
	}
}
