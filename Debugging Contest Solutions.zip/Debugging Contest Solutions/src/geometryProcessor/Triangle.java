package geometryProcessor;

public class Triangle implements Shape {

	double length;
	double area;
	String colour;
	String name;

	public Triangle(double l, String c, String n) {
		length = l;
		colour = c;
		name = n;
		area = getArea();
	}

	public String getShape() {
		return "Triangle";
	}

	public String getName() {
		return name;
	}

	public String getColour() {
		return colour;
	}

	public double getArea() {
		return (Math.sqrt(3) / 4) * length;
	}

	public void setLength(double l) {
		length = l;
		area = getArea();
	}

	public void setColour(String c) {
		colour = c;
	}

	public void setName(String n) {
		name = n;
	}

}
